import React, { useState } from 'react';
import type { CrosssellSuggestion, SuggestedProduct } from '../suggestions';

interface CrosssellChipProps {
  suggestions: CrosssellSuggestion[];
  onAccept: (ruleId: string, productId: string) => void;
  onDismiss: (ruleId: string) => void;
}

function formatPrice(price: number) {
  return `${(price / 100).toFixed(2)} €`;
}

function CrosssellImage({ product }: { product: SuggestedProduct }) {
  const [failed, setFailed] = useState(false);

  if (product.imageUrl && !failed) {
    return (
      <img
        className="crosssell-chip-img"
        src={product.imageUrl}
        alt={product.name}
        onError={() => setFailed(true)}
      />
    );
  }

  return <div className="crosssell-chip-img crosssell-chip-img-placeholder" aria-hidden="true" />;
}

export function CrosssellChip({
  suggestions,
  onAccept,
  onDismiss,
}: CrosssellChipProps) {
  if (suggestions.length === 0) {
    return null;
  }

  return (
    <div className="crosssell-container">
      <p className="crosssell-label">Te puede interesar</p>

      {suggestions.slice(0, 2).map((suggestion) => (
        <div
          key={suggestion.ruleId}
          className="crosssell-chip"
          onClick={() => onAccept(suggestion.ruleId, suggestion.product.id)}
        >
          <CrosssellImage product={suggestion.product} />

          <div className="crosssell-chip-info">
            <p className="crosssell-chip-reason">{suggestion.reason}</p>
            <p className="crosssell-chip-price">+{formatPrice(suggestion.product.price)}</p>
          </div>

          <button
            className="crosssell-chip-dismiss"
            aria-label={`Ocultar sugerencia de ${suggestion.product.name}`}
            onClick={(event) => {
              event.stopPropagation();
              onDismiss(suggestion.ruleId);
            }}
          >
            ×
          </button>
          <button
            className="crosssell-chip-add"
            aria-label={`Añadir ${suggestion.product.name}`}
            onClick={(event) => {
              event.stopPropagation();
              onAccept(suggestion.ruleId, suggestion.product.id);
            }}
          >
            +
          </button>
        </div>
      ))}
    </div>
  );
}
